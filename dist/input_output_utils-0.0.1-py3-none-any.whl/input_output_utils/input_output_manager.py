
import os
from typing import Union

import pandas as pd


def excel_only(func):
    def wrapper(self, *args, **kwargs):
        if not isinstance(self._manager, _ExcelManager):
            raise TypeError(f"{func.__name__} can only be used for Excel output files.\n"
                            f"Output path {self._output_path} is not an Excel path.")
        return func(self, *args, **kwargs)
    return wrapper


class _ExcelManager:

    def __init__(self, output_path: str):
        self._writer = pd.ExcelWriter(output_path, engine='openpyxl')
        self._sheet_data = dict()

    def add_data(self, data: pd.DataFrame, sheet_name: str):
        self._sheet_data[sheet_name] = data
        data.to_excel(self._writer, sheet_name=sheet_name, index=False)

    def _fetch_worksheet(self, sheet_name: str):
        return self._writer.sheets[sheet_name]

    def autofit_column_widths(self, sheet_name: str):
        from openpyxl.utils import get_column_letter
        worksheet = self._fetch_worksheet(sheet_name=sheet_name)
        data = self._sheet_data[sheet_name]

        for i, col in enumerate(data.columns, 1):
            max_length = max(data[col].astype(str).map(len).max(), len(col))
            worksheet.column_dimensions[get_column_letter(i)].width = max_length + 2

    def export(self):
        self._writer.close()



class _CsvManager:

    def __init__(self,
                 output_path: str,
                 data: pd.DataFrame = None):
        self._output_path = output_path
        self._data = data

    def add_data(self, data: pd.DataFrame):
        print("Overwriting previous data in CsvManager.")
        self._data = data

    def export(self):
        if not self._data:
            raise ValueError(f"CsvManager has no data to export.")

        self._data.to_csv(self._output_path)


class InputOutputManager:
    _manager: Union[_ExcelManager, _CsvManager]

    def __init__(self,
                 output_path: str,
                 data: pd.DataFrame = None,
                 sheet_name: str = None):
        self.output_path = output_path

        ext = os.path.splitext(output_path)[1].lower()
        if ext in ('.xlsx', '.xls'):
            self._manager = _ExcelManager(output_path)
        elif ext == '.csv':
            self._manager = _CsvManager(output_path)
        else:
            raise ValueError(f"Output path {output_path} is not supported.")

        if data:
            self.add_data(
                data=data,
                sheet_name=sheet_name
            )

    @property
    def is_excel(self):
        return isinstance(self._manager, _ExcelManager)

    @property
    def is_csv(self):
        return isinstance(self._manager, _CsvManager)

    @excel_only
    def autofit_column_widths(self, sheet_name: str):
        self._manager.autofit_column_widths(sheet_name=sheet_name)

    def add_data(self, data: pd.DataFrame, sheet_name: str = None):
        if self.is_excel:
            if not sheet_name:
                raise ValueError(f"Sheet name must be included as an argument when the output is an Excel file.")

            self._manager.add_data(
                data=data,
                sheet_name=sheet_name
            )
        elif self.is_csv:
            if sheet_name:
                raise ValueError(f"Sheet name is an invalid argument when the output is a CSV file.")

            self._manager.add_data(
                data=data
            )

    def export(self):
        self._manager.export()
